

#include <iostream>
#include "ofMain.h"

class LevelController {
public:
    float start_time;
    float interval_time;
    
    void setup(float e);
    void update();
    bool should_spawn();
    
};
