#include <iostream>
#include "ofMain.h"

class Life {
public:
    ofPoint pos;
    float speed;
    float width;
    
    ofImage * img;
    
    void setup(ofImage * img);
    void update();
    void draw();
    
};
